{{/*
NOTE: We need to load this file first thing before all other resources to support backward compatibility.

      Helm prioritizes files that are deeply nested in subdirectories when it is determining the render order.
      see the sort function in Helm:
      https://github.com/helm/helm/blob/d58d7b376265338e059ff11c71267b5a6cf504c3/pkg/engine/engine.go#L347-L356

      Because of this sort order, and that we have nested subcharts such that
      one of the rendered templates is:
      charts/keycloak/charts/postgresql/charts/common/templates/validations/_validations.tpl,
      we need this z_compatibility_helpers.tpl to be nested in at least 8 folders.

      In addition to the subdirectory ordering, Helm also orders the templates
      alphabetically descending within the same folder level, which is why it
      is named with a "z_" inside the zeebe directory. so Helm will process
      this file first, and all migration steps will be applied to all templates
      in the chart implicitly:
      https://github.com/helm/helm/blob/d58d7b376265338e059ff11c71267b5a6cf504c3/pkg/engine/engine.go#L362-L369
*/}}


{{/*
********************************************************************************
* Camunda 8.5 backward compatibility.

Overview:
    Backward compatibility with values syntax before Camunda Helm chart v10.0.0 (Camunda 8.5 cycle).

Approach:
    Using deep copy and deep merge functions to override new keys using the old key.
    https://helm.sh/docs/chart_template_guide/function_list/#mergeoverwrite-mustmergeoverwrite
********************************************************************************
*/}}

{{/*
OpenShift.
The `elasticsearch.sysctlImage` container adjusts the virtual memory and file descriptors of the machine needed for Elasticsearch.
By default, the `sysctlImage` container will fail on OpenShift because it requires privileged mode.
Also, recent OpenShift versions (> 4.10) have adjusted the virtual memory of the machine by default.
*/}}
{{- if eq .Values.global.compatibility.openshift.adaptSecurityContext "force" -}}
    {{- $_ := set .Values.elasticsearch.sysctlImage "enabled" false -}}
{{- end -}}


{{/*
OpenShift.
The label `tuned.openshift.io/elasticsearch` is added to ensure compatibility with the previous Camunda Helm charts.
Without this label, the Helm upgrade will fail for OpenShift because it is already set for the volumeClaimTemplate.
This is only needed when elasticsearch is actually enabled and deployed.
*/}}

{{- if and (eq .Values.global.compatibility.openshift.adaptSecurityContext "force") .Values.elasticsearch.enabled -}}
    {{- if not (hasKey .Values.elasticsearch "commonLabels") -}}
        {{- $_ := set .Values.elasticsearch "commonLabels" (dict) -}}
    {{- end -}}
    {{- if not (hasKey .Values.elasticsearch.commonLabels "tuned.openshift.io/elasticsearch") -}}
        {{- $_ := set .Values.elasticsearch.commonLabels "tuned.openshift.io/elasticsearch" "" -}}
    {{- end -}}
{{- end -}}

{{/*
********************************************************************************
* Camunda 8.8 => 8.9

Overview:
    Backward compatibility to make the values of Camunda Helm chart v13.0.0 (Camunda 8.8)
    works with Camunda Helm chart v14.0.0 (Camunda 8.9).
********************************************************************************
*/}}

{{/*
orchestration.profiles.identity => orchestration.profiles.admin
The "identity" profile has been renamed to "admin" in Camunda 8.9.
This mapping prefers the new "admin" key if both are present.
*/}}
{{- if hasKey .Values.orchestration.profiles "identity" -}}
    {{- $_ := set .Values "_deprecatedIdentityProfileUsed" true -}}
    {{- if not (hasKey .Values.orchestration.profiles "admin") -}}
        {{- $_ := set .Values.orchestration.profiles "admin" .Values.orchestration.profiles.identity -}}
    {{- end -}}
    {{- $_ := unset .Values.orchestration.profiles "identity" -}}
{{- end -}}
